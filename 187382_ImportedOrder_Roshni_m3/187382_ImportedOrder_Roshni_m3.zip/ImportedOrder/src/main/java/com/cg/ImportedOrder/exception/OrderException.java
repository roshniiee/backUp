package com.cg.ImportedOrder.exception;

public class OrderException extends Exception {

	public OrderException() {

	}

	public OrderException(String str) {
		super(str);
	}

}
