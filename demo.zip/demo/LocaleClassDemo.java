package demo;

import java.util.Currency;
import java.util.Locale;

public class LocaleClassDemo {
	public static void main(String args[]) {
		Locale locale=new Locale("fr","FR");
				int amount=1000;
		Currency c=Currency.getInstance(locale);
		System.out.println(amount+" "+c.getCurrencyCode());
		System.out.println(c.getSymbol());
		System.out.println(c.getDisplayName());
	}

}
