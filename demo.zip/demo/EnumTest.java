package demo;
enum TrafficSignal{
	RED,GREEN,ORANGE;
}

public class EnumTest {
TrafficSignal color;
public EnumTest(TrafficSignal color) {
	this.color=color;
}
public void selectColor() {
	switch(color)
	{
	case RED:
		System.out.println("WAIT");
		break;
	case GREEN:
		System.out.println("GO");
		break;
	case ORANGE:
		System.out.println("slow down");
		break;
		default:
			System.out.println("not int the choice");
			break;
	}
}
public static void main(String args[]) {
	EnumTest et=new EnumTest(TrafficSignal.RED);
	et.selectColor();
}
}
