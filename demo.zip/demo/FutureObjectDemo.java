package demo;

import java.util.concurrent.*;

public class FutureObjectDemo {
public static void main(String args[]) {
	ExecutorService ec=Executors.newFixedThreadPool(3);
	DisplayTask dobj1=new DisplayTask("hi");
	DisplayTask dobj2=new DisplayTask("hello");
	Callable<String> dobj3=new DisplayTask("Roshni");
	Future<String> fobj1=ec.submit(dobj1);
	Future<String> fobj2=ec.submit(dobj2);
	Future<String> fobj3=ec.submit(dobj3);
	try {
		System.out.println(fobj1.get());
		System.out.println(fobj2.get());
		System.out.println(fobj3.get());
	}
	catch(Exception e) {
		System.out.println(e);
	}
	
	System.out.println();
}
}
