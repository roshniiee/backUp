package demo;
import java.util.*;

public class SortingCollection {
	public static void main(String args[]) {
		int a[]= {23,56,43,67};
		Arrays.sort(a);
		for(int i:a)
			System.out.println(i);
		System.out.println("****************");
		LinkedList<String> lObj=new LinkedList<String>();
		lObj.add("rose");
		lObj.add("varsh");
		lObj.add("jack");
		System.out.println(lObj);
		System.out.println("****************");
		Collections.sort(lObj);
		System.out.println(lObj);
		
	}

}
