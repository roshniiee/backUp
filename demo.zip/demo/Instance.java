package demo;
class Base{
	
}
class Sub extends Base{
	
}


public class Instance {
	public static void main(String args[]) {
		Instance obj=new Instance();
		Instance obj1=new Instance();
		Base b1=new Base();
		Sub s1=new Sub();
		if(s1 instanceof Base)
			System.out.println("true");
	}

}
