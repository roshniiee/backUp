package demo;

import java.util.Iterator;
import java.util.Set;
import java.util.TreeSet;

/*import java.util.HashSet;
import java.util.Set;

package demo;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedList;

public class tryy {

	public static void main(String args[]){  
	LinkedList<String> al=new LinkedList<String>();  
	al.add("Ravi");  
	al.add("Vijay");  
	al.add("Ravi");  
	al.add("Ajay");  
	
	System.out.println(al.get(2));
	Iterator<String> itr=al.iterator();  
	while(itr.hasNext()){  
	System.out.println(itr.next());  
	}  
	}  
	}  
	
	public static void main(String args[]){  
	ArrayList<String> list=new ArrayList<String>();//Creating arraylist  
	list.add("Ravi");//Adding object in arraylist  
	list.add("Vijay");  
	list.add("Ravi");  
	list.add("Ajay");  
	System.out.println(list.get(2));
	//Traversing list through Iterator  
	Iterator itr=list.iterator();  
	while(itr.hasNext()){  
	System.out.println(itr.next());  
	}  
	}  
	  



public class tryy {

public static void main(String[] args) {
boolean[] boolArr= new boolean[5];
Set<Integer> set = new HashSet<Integer>();
boolArr[0] = set.add(1);
boolArr[1] = set.add(2);
boolArr[2] = set.add(3);
boolArr[3] = set.add(4);
boolArr[4] = set.add(5);
for(Integer index : set)
System.out.print(index + " ");
}
}*/



	
	/*class X { void do1() { } } 

	 class Y extends X { void do2() { } } 

	 

	 class Chrome { 

	 public  static void main(String [] args) { 

	 X x1 = new X(); 

	X x2 = new Y(); 

	 Y y1 = new Y(); 


	 } 

	 } 
	*/
public class tryy{
public static void before() { 

Set set = new TreeSet(); 

set.add("2"); 

set.add(3); 

set.add("1"); 

Iterator it = set.iterator(); 

while (it.hasNext()) 

System.out.print(it.next() + " "); 

} 
}
	
/*	 static TreeSet<Strin
 * g> map = new TreeSet<String>(); 
public static void main(String args[]) {
	 map.add("one"); 

	 map.add("two"); 

	 map.add("three"); 

	 map.add("four"); 

	 map.add("one"); 

	 Iterator<String> it = map.iterator(); 

	while (it.hasNext() ) { 

	System.out.print( it.next() + " " ); 

	 } 
}
*/




